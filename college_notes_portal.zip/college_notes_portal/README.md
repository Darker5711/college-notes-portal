College Notes Portal - MVP (single-file Flask app)
-------------------------------------------------
What's inside:
- college_notes_portal.py    (the main app)
- requirements.txt           (python packages to install)
- uploads/                   (folder where uploaded files are stored)
- notes_portal.db            (SQLite DB created on first run)

Quick start (Windows):
1. Install Python 3.8+ from python.org and ensure 'python' is on PATH.
2. Unzip the downloaded folder.
3. Open Command Prompt inside the folder.
4. Create and activate virtual environment:
   python -m venv venv
   venv\Scripts\activate
5. Install requirements:
   pip install -r requirements.txt
6. Run the app:
   python college_notes_portal.py
7. Open http://127.0.0.1:5000 in your browser.

Quick start (Linux / Mac):
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   python3 college_notes_portal.py
   Open http://127.0.0.1:5000

Notes:
- First run will create a SQLite DB (notes_portal.db) and seed sample semesters/subjects.
- Create a faculty account to upload notes. Students can then view/download them.
- This is a learning project. Don't use it in production without security improvements.

Need help? Reply here and I'll guide you step-by-step.

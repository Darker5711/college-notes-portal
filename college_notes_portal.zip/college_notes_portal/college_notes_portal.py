
"""
College Notes Portal - Single-file Flask app (MVP)

Features:
- Student & Faculty registration/login
- Semester & Subject organization
- Faculty: upload / edit / delete notes
- Students: browse by semester -> subject -> notes, view, download, share links

How to run:
1. Install dependencies:
   pip install -r requirements.txt
2. Run:
   python college_notes_portal.py
3. Open http://127.0.0.1:5000

NOTE: This is an MVP for learning. For production, add CSRF protection, file scanning, better error handling,
use a stronger DB, HTTPS, and secure file storage (S3), and rate limiting.
"""

import os
import sqlite3
from datetime import datetime
from flask import Flask, request, redirect, url_for, render_template, session, send_from_directory, flash, jsonify
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from jinja2 import DictLoader

BASE_DIR = os.path.dirname(__file__)
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
DB_PATH = os.path.join(BASE_DIR, 'notes_portal.db')
ALLOWED_EXT = set(['pdf','doc','docx','txt','ppt','pptx','png','jpg','jpeg'])

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
app.secret_key = 'replace-this-with-a-secure-random-key'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50 MB

# ------------------ Database helpers ------------------

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('student','faculty'))
    );
    CREATE TABLE IF NOT EXISTS semesters (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL
    );
    CREATE TABLE IF NOT EXISTS subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        semester_id INTEGER NOT NULL,
        FOREIGN KEY(semester_id) REFERENCES semesters(id)
    );
    CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        filename TEXT NOT NULL,
        subject_id INTEGER NOT NULL,
        uploaded_by INTEGER NOT NULL,
        uploaded_at TEXT NOT NULL,
        FOREIGN KEY(subject_id) REFERENCES subjects(id),
        FOREIGN KEY(uploaded_by) REFERENCES users(id)
    );
    """)
    conn.commit()
    # seed a few semesters/subjects if empty
    cur.execute('SELECT COUNT(*) as c FROM semesters')
    if cur.fetchone()['c'] == 0:
        semesters = ['Semester 1','Semester 2','Semester 3','Semester 4']
        for s in semesters:
            cur.execute('INSERT INTO semesters (name) VALUES (?)', (s,))
        conn.commit()
    cur.execute('SELECT COUNT(*) as c FROM subjects')
    if cur.fetchone()['c'] == 0:
        # sample subjects mapped to semester ids 1-4
        samples = [
            ('Mathematics I',1),('Physics I',1),('Programming I',1),
            ('Mathematics II',2),('Data Structures',2),('Electronics',2),
            ('Algorithms',3),('DBMS',3),('Operating Systems',3),
            ('Networks',4),('AI',4)
        ]
        for name, sem in samples:
            cur.execute('INSERT INTO subjects (name, semester_id) VALUES (?,?)', (name,sem))
        conn.commit()
    conn.close()

init_db()

# ------------------ Utilities ------------------

def allowed_file(filename):
    if '.' not in filename:
        return False
    ext = filename.rsplit('.',1)[1].lower()
    return ext in ALLOWED_EXT

def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    conn = get_db()
    user = conn.execute('SELECT id,name,email,role FROM users WHERE id=?',(uid,)).fetchone()
    conn.close()
    return user

# ------------------ Templates ------------------

BASE_HTML = """
<!doctype html>
<title>College Notes Portal</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mini.css/3.0.1/mini-default.min.css">
<nav>
  <a href="/">Home</a>
  {% if user %}
    <a href="/dashboard">Dashboard</a>
    <a href="/logout">Logout ({{ user['name'] }})</a>
  {% else %}
    <a href="/login">Login</a>
    <a href="/register">Register</a>
  {% endif %}
</nav>
<div class="container">
  {% with messages = get_flashed_messages() %}
    {% if messages %}
      <section>
        {% for m in messages %}
          <div class="row"><div class="card">{{ m }}</div></div>
        {% endfor %}
      </section>
    {% endif %}
  {% endwith %}
  {% block body %}{% endblock %}
</div>
"""

HOME_HTML = """{% extends 'base' %}{% block body %}
  <h2>Welcome to College Notes Portal</h2>
  <p>Browse notes semester & subject-wise. Faculty can upload notes from their dashboard.</p>
  <h3>Semesters</h3>
  <div class="row">
  {% for sem in semesters %}
    <div class="card">
      <h4>{{ sem['name'] }}</h4>
      <a href="/semester/{{ sem['id'] }}">Open</a>
    </div>
  {% endfor %}
  </div>
{% endblock %}"""

REGISTER_HTML = """{% extends 'base' %}{% block body %}
  <h3>Register</h3>
  <form method="post">
    <label>Name <input name="name" required></label>
    <label>Email <input name="email' type='email' required></label>
    <label>Password <input name="password" type="password" required></label>
    <label>Role
      <select name="role">
        <option value="student">Student</option>
        <option value="faculty">Faculty</option>
      </select>
    </label>
    <button type="submit">Register</button>
  </form>
{% endblock %}"""

LOGIN_HTML = """{% extends 'base' %}{% block body %}
  <h3>Login</h3>
  <form method="post">
    <label>Email <input name="email" type="email" required></label>
    <label>Password <input name="password" type="password" required></label>
    <button type="submit">Login</button>
  </form>
{% endblock %}"""

SEMESTER_HTML = """{% extends 'base' %}{% block body %}
  <h3>{{ semester['name'] }}</h3>
  <div class="row">
  {% for sub in subjects %}
    <div class="card">
      <h4>{{ sub['name'] }}</h4>
      <a href="/subject/{{ sub['id'] }}">Open</a>
    </div>
  {% endfor %}
  </div>
{% endblock %}"""

SUBJECT_HTML = """{% extends 'base' %}{% block body %}
  <h3>{{ subject['name'] }} — {{ semester['name'] }}</h3>
  {% if user and user['role']=='faculty' %}
    <p><a href="/upload?subject_id={{ subject['id'] }}">Upload new note</a></p>
  {% endif %}
  <table>
    <thead><tr><th>Title</th><th>Uploaded By</th><th>Uploaded At</th><th>Actions</th></tr></thead>
    <tbody>
    {% for n in notes %}
      <tr>
        <td>{{ n['title'] }}</td>
        <td>{{ n['uploader_name'] }}</td>
        <td>{{ n['uploaded_at'] }}</td>
        <td>
          <a href="/view/{{ n['id'] }}">View</a> |
          <a href="/download/{{ n['id'] }}">Download</a>
          {% if user and user['role']=='faculty' and user['id']==n['uploaded_by'] %}
            | <a href="/edit/{{ n['id'] }}">Edit</a> | <a href="/delete/{{ n['id'] }}" onclick="return confirm('Delete note?')">Delete</a>
          {% endif %}
        </td>
      </tr>
    {% endfor %}
    </tbody>
  </table>
{% endblock %}"""

UPLOAD_HTML = """{% extends 'base' %}{% block body %}
  <h3>Upload Note</h3>
  <form method="post" enctype="multipart/form-data">
    <label>Title <input name="title" required></label>
    <label>Description <textarea name="description"></textarea></label>
    <label>Semester
      <select id="sem" name="semester_id" onchange="fetchSubjects()">
        {% for s in semesters %}
          <option value="{{ s['id'] }}" {% if s['id']==selected_sem %}selected{% endif %}>{{ s['name'] }}</option>
        {% endfor %}
      </select>
    </label>
    <label>Subject
      <select id="subject" name="subject_id">
        {% for sub in subjects %}
          <option value="{{ sub['id'] }}" {% if sub['id']==selected_subject %}selected{% endif %}>{{ sub['name'] }}</option>
        {% endfor %}
      </select>
    </label>
    <label>File <input type="file" name="file" required></label>
    <button type="submit">Upload</button>
  </form>
  <script>
    async function fetchSubjects(){
      const sem = document.getElementById('sem').value;
      const res = await fetch('/api/subjects?semester_id='+sem);
      const data = await res.json();
      const sel = document.getElementById('subject');
      sel.innerHTML='';
      data.forEach(s=>{ const o=document.createElement('option'); o.value=s.id; o.textContent=s.name; sel.appendChild(o); });
    }
  </script>
{% endblock %}"""

VIEW_HTML = """{% extends 'base' %}{% block body %}
  <h3>{{ note['title'] }}</h3>
  <p><strong>Subject:</strong> {{ subject['name'] }} | <strong>Semester:</strong> {{ semester['name'] }}</p>
  <p>{{ note['description'] }}</p>
  <p>Uploaded by {{ uploader['name'] }} at {{ note['uploaded_at'] }}</p>
  <p>
    <a href="/download/{{ note['id'] }}">Download</a>
    | <a href="/share/{{ note['id'] }}">Share Link</a>
  </p>
  {% if note_preview %}
    <iframe src="{{ note_preview }}" width="100%" height="600px"></iframe>
  {% endif %}
{% endblock %}"""

EDIT_HTML = """{% extends 'base' %}{% block body %}
  <h3>Edit Note</h3>
  <form method="post">
    <label>Title <input name="title" value="{{ note['title'] }}" required></label>
    <label>Description <textarea name="description">{{ note['description'] }}</textarea></label>
    <button type="submit">Save</button>
  </form>
{% endblock %}"""

# ------------------ Template loader ------------------
from flask import render_template

@app.context_processor
def inject_user():
    return dict(user=current_user())

# Register templates using DictLoader
app.jinja_loader = DictLoader({
    'base': BASE_HTML,
    'home.html': HOME_HTML,
    'register.html': REGISTER_HTML,
    'login.html': LOGIN_HTML,
    'semester.html': SEMESTER_HTML,
    'subject.html': SUBJECT_HTML,
    'upload.html': UPLOAD_HTML,
    'view.html': VIEW_HTML,
    'edit.html': EDIT_HTML,
})

# ------------------ Routes ------------------

@app.route('/')
def home():
    conn = get_db()
    semesters = conn.execute('SELECT * FROM semesters ORDER BY id').fetchall()
    conn.close()
    return render_template('home.html', semesters=semesters)

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        name = request.form['name'].strip()
        email = request.form['email'].strip().lower()
        password = request.form['password']
        role = request.form['role']
        pw_hash = generate_password_hash(password)
        conn = get_db()
        try:
            conn.execute('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)', (name,email,pw_hash,role))
            conn.commit()
            flash('Registered. Please login.')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Email already registered.')
        finally:
            conn.close()
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form['email'].strip().lower()
        password = request.form['password']
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
        conn.close()
        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            flash('Logged in')
            return redirect(url_for('dashboard'))
        flash('Invalid credentials')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out')
    return redirect(url_for('home'))

@app.route('/dashboard')
def dashboard():
    user = current_user()
    if not user:
        return redirect(url_for('login'))
    conn = get_db()
    if user['role']=='faculty':
        notes = conn.execute('SELECT n.*, u.name as uploader_name, s.name as subject_name FROM notes n JOIN users u ON n.uploaded_by=u.id JOIN subjects s ON n.subject_id=s.id WHERE uploaded_by=? ORDER BY uploaded_at DESC',(user['id'],)).fetchall()
        conn.close()
        html = '<h3>Faculty Dashboard</h3>'
        html += '<p><a href="/upload">Upload Note</a></p>'
        html += '<ul>'
        for n in notes:
            html += f"<li>{n['title']} — {n['subject_name']} (<a href='/edit/{n['id']}'>Edit</a> | <a href='/delete/{n['id']}'>Delete</a>)</li>"
        html += '</ul>'
        return html
    else:
        # student
        semesters = conn.execute('SELECT * FROM semesters ORDER BY id').fetchall()
        conn.close()
        return render_template('home.html', semesters=semesters)

@app.route('/semester/<int:sem_id>')
def semester_view(sem_id):
    conn = get_db()
    semester = conn.execute('SELECT * FROM semesters WHERE id=?',(sem_id,)).fetchone()
    subjects = conn.execute('SELECT * FROM subjects WHERE semester_id=?',(sem_id,)).fetchall()
    conn.close()
    if not semester:
        return 'Semester not found',404
    return render_template('semester.html', semester=semester, subjects=subjects)

@app.route('/subject/<int:sub_id>')
def subject_view(sub_id):
    conn = get_db()
    subject = conn.execute('SELECT s.*, sem.name as semester_name FROM subjects s JOIN semesters sem ON s.semester_id=sem.id WHERE s.id=?',(sub_id,)).fetchone()
    if not subject:
        conn.close()
        return 'Subject not found',404
    notes = conn.execute('SELECT n.*, u.name as uploader_name FROM notes n JOIN users u ON n.uploaded_by=u.id WHERE n.subject_id=? ORDER BY uploaded_at DESC',(sub_id,)).fetchall()
    conn.close()
    return render_template('subject.html', subject=subject, semester={'id': subject['semester_id'], 'name': subject['semester_name']}, notes=notes)

@app.route('/upload', methods=['GET','POST'])
def upload():
    user = current_user()
    if not user or user['role']!='faculty':
        flash('Faculty only: login as faculty')
        return redirect(url_for('login'))
    conn = get_db()
    semesters = conn.execute('SELECT * FROM semesters ORDER BY id').fetchall()
    selected_subject = request.args.get('subject_id', type=int)
    selected_sem = None
    subjects = []
    if selected_subject:
        sub = conn.execute('SELECT * FROM subjects WHERE id=?',(selected_subject,)).fetchone()
        if sub:
            selected_sem = sub['semester_id']
            subjects = conn.execute('SELECT * FROM subjects WHERE semester_id=?',(selected_sem,)).fetchall()
    else:
        subjects = conn.execute('SELECT * FROM subjects WHERE semester_id=1').fetchall()
    if request.method=='POST':
        title = request.form['title'].strip()
        description = request.form.get('description','').strip()
        subject_id = int(request.form['subject_id'])
        f = request.files.get('file')
        if not f or f.filename=='' or not allowed_file(f.filename):
            flash('Invalid file')
            return redirect(request.url)
        filename = secure_filename(f.filename)
        timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
        fname = f"{timestamp}_{filename}"
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], fname)
        f.save(save_path)
        conn.execute('INSERT INTO notes (title,description,filename,subject_id,uploaded_by,uploaded_at) VALUES (?,?,?,?,?,?)', (title,description,fname,subject_id,user['id'],datetime.utcnow().isoformat()))
        conn.commit()
        conn.close()
        flash('Uploaded')
        return redirect(url_for('dashboard'))
    conn.close()
    return render_template('upload.html', semesters=semesters, subjects=subjects, selected_subject=selected_subject, selected_sem=selected_sem)

@app.route('/api/subjects')
def api_subjects():
    sem_id = request.args.get('semester_id', type=int)
    conn = get_db()
    subs = conn.execute('SELECT * FROM subjects WHERE semester_id=?',(sem_id,)).fetchall()
    conn.close()
    return jsonify([dict(x) for x in subs])

@app.route('/view/<int:note_id>')
def view_note(note_id):
    conn = get_db()
    note = conn.execute('SELECT * FROM notes WHERE id=?',(note_id,)).fetchone()
    if not note:
        conn.close()
        return 'Note not found',404
    uploader = conn.execute('SELECT id,name FROM users WHERE id=?',(note['uploaded_by'],)).fetchone()
    subject = conn.execute('SELECT * FROM subjects WHERE id=?',(note['subject_id'],)).fetchone()
    semester = conn.execute('SELECT * FROM semesters WHERE id=?',(subject['semester_id'],)).fetchone()
    conn.close()
    note_preview = None
    if note['filename'].lower().endswith('.pdf'):
        note_preview = url_for('uploaded_file', filename=note['filename'])
    return render_template('view.html', note=note, uploader=uploader, subject=subject, semester=semester, note_preview=note_preview)

@app.route('/download/<int:note_id>')
def download(note_id):
    conn = get_db()
    note = conn.execute('SELECT filename FROM notes WHERE id=?',(note_id,)).fetchone()
    conn.close()
    if not note:
        return 'Not found',404
    return send_from_directory(app.config['UPLOAD_FOLDER'], note['filename'], as_attachment=True)

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/share/<int:note_id>')
def share(note_id):
    link = request.url_root.rstrip('/') + url_for('view_note', note_id=note_id)
    return f'Shareable link: <a href="{link}">{link}</a>'

@app.route('/edit/<int:note_id>', methods=['GET','POST'])
def edit_note(note_id):
    user = current_user()
    if not user:
        return redirect(url_for('login'))
    conn = get_db()
    note = conn.execute('SELECT * FROM notes WHERE id=?',(note_id,)).fetchone()
    if not note:
        conn.close()
        return 'Not found',404
    if user['role']!='faculty' or user['id']!=note['uploaded_by']:
        conn.close()
        return 'Forbidden',403
    if request.method=='POST':
        title = request.form['title'].strip()
        description = request.form.get('description','').strip()
        conn.execute('UPDATE notes SET title=?,description=? WHERE id=?',(title,description,note_id))
        conn.commit()
        conn.close()
        flash('Saved')
        return redirect(url_for('dashboard'))
    conn.close()
    return render_template('edit.html', note=note)

@app.route('/delete/<int:note_id>')
def delete_note(note_id):
    user = current_user()
    if not user:
        return redirect(url_for('login'))
    conn = get_db()
    note = conn.execute('SELECT * FROM notes WHERE id=?',(note_id,)).fetchone()
    if not note:
        conn.close()
        return 'Not found',404
    if user['role']!='faculty' or user['id']!=note['uploaded_by']:
        conn.close()
        return 'Forbidden',403
    try:
        os.remove(os.path.join(app.config['UPLOAD_FOLDER'], note['filename']))
    except Exception:
        pass
    conn.execute('DELETE FROM notes WHERE id=?',(note_id,))
    conn.commit()
    conn.close()
    flash('Deleted')
    return redirect(url_for('dashboard'))

# ------------------ Run ------------------
if __name__ == '__main__':
    app.run(debug=True)
